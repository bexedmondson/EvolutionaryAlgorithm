public class Item {

	//weight of item
	private int weight;

	//bin item is in
	private int binNumber;
	
	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getBinNumber() {
		return binNumber;
	}

	public void setBinNumber(int binNumber) {
		this.binNumber = binNumber;
	}
}